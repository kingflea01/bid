#!/usr/bin/env python3
"""Feasibility test: clone a complex table from a tender DOCX into a new DOCX.

Verifies merged cells, grid widths, cell text and fonts survive the OOXML deep copy.
"""

import copy
import json
import statistics
import time
from pathlib import Path

import docx
from docx.oxml.ns import qn

SOURCE = Path(
    "/Users/kingflea/Documents/Trae-CN/shoot1/input/"
    "XXXX营业部ABC软件单一来源采购文件-自采.docx"
)
TARGET = Path("/Users/kingflea/Documents/Trae-CN/shoot1/feasibility/clone_test.docx")


def find_table(document):
    for index, table in enumerate(document.tables):
        text = "\n".join(cell.text for row in table.rows for cell in row.cells)
        if "分项名称" in text and ("价税" in text or "税额" in text):
            return index, table
    raise SystemExit("target table not found")


def table_stats(table):
    tbl = table._tbl
    grid_cols = tbl.findall(".//" + qn("w:tblGrid") + "/" + qn("w:gridCol"))
    widths = [col.get(qn("w:w")) for col in grid_cols]
    rows = tbl.findall(qn("w:tr"))
    grid_span = tbl.findall(".//" + qn("w:gridSpan"))
    v_merge = tbl.findall(".//" + qn("w:vMerge"))
    nested = [node for node in tbl.iter(qn("w:tbl")) if node is not tbl]
    images = tbl.findall(".//" + qn("a:blip"))
    hyperlinks = tbl.findall(".//" + qn("w:hyperlink"))
    style = tbl.find(qn("w:tblPr") + "/" + qn("w:tblStyle"))
    return {
        "rows": len(rows),
        "grid_cols": len(grid_cols),
        "grid_widths": widths,
        "grid_width_sum": sum(int(w) for w in widths if w and w.isdigit()),
        "grid_span_count": len(grid_span),
        "v_merge_count": len(v_merge),
        "nested_tables": len(nested),
        "images": len(images),
        "hyperlinks": len(hyperlinks),
        "table_style": style.get(qn("w:val")) if style is not None else None,
    }


def first_rows(table, count=3):
    result = []
    for row in table.rows[:count]:
        result.append([cell.text.strip() for cell in row.cells])
    return result


def font_sample(table):
    for row in table.rows:
        for cell in row.cells:
            for paragraph in cell.paragraphs:
                for run in paragraph.runs:
                    if not run.text.strip():
                        continue
                    r_pr = run._r.rPr
                    fonts = r_pr.find(qn("w:rFonts")) if r_pr is not None else None
                    size = r_pr.find(qn("w:sz")) if r_pr is not None else None
                    return {
                        "text": run.text.strip()[:30],
                        "ascii": fonts.get(qn("w:ascii")) if fonts is not None else None,
                        "eastAsia": fonts.get(qn("w:eastAsia")) if fonts is not None else None,
                        "size_half_points": size.get(qn("w:val")) if size is not None else None,
                        "bold": run.bold,
                    }
    return None


def build_target(source_path, table_element, output_path):
    document = docx.Document(str(source_path))
    body = document.element.body
    for child in list(body):
        if not child.tag.endswith("sectPr"):
            body.remove(child)
    sect_pr = body.find(qn("w:sectPr"))
    new_table = copy.deepcopy(table_element)
    if sect_pr is not None:
        sect_pr.addprevious(new_table)
    else:
        body.append(new_table)
    document.save(str(output_path))


def main():
    document = docx.Document(str(SOURCE))
    index, table = find_table(document)
    source_stats = table_stats(table)

    copy_times = []
    for _ in range(200):
        start = time.perf_counter()
        copy.deepcopy(table._tbl)
        copy_times.append((time.perf_counter() - start) * 1000)

    build_times = []
    for _ in range(20):
        start = time.perf_counter()
        build_target(SOURCE, table._tbl, TARGET)
        build_times.append((time.perf_counter() - start) * 1000)

    target_doc = docx.Document(str(TARGET))
    target_table = target_doc.tables[0]
    target_stats = table_stats(target_table)

    source_rows = first_rows(table, 4)
    target_rows = first_rows(target_table, 4)
    text_match = source_rows == target_rows

    result = {
        "table_index": index,
        "source_stats": source_stats,
        "target_stats": target_stats,
        "structure_match": source_stats == target_stats,
        "first_rows_match": text_match,
        "source_first_rows": source_rows,
        "target_first_rows": target_rows,
        "source_font_sample": font_sample(table),
        "target_font_sample": font_sample(target_table),
        "deepcopy_ms_median": round(statistics.median(copy_times), 4),
        "full_build_ms_median": round(statistics.median(build_times), 2),
        "target_file": str(TARGET),
        "target_size_bytes": TARGET.stat().st_size,
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
