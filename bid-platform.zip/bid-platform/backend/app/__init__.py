"""Bid platform backend."""
